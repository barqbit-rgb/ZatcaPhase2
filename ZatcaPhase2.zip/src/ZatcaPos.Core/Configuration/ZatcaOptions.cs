﻿namespace ZatcaPos.Core.Configuration
{
    public class ZatcaOptions
    {
        /// <summary>
        /// Environment: Simulation / Production
        /// </summary>
        public string Environment { get; set; } = "Simulation";

        /// <summary>
        /// Base URL of ZATCA endpoint
        /// </summary>
        public string BaseUrl { get; set; } = string.Empty;

        /// <summary>
        /// API Key for authentication (used in simulation / optional in production)
        /// </summary>
        public string ApiKey { get; set; } = string.Empty;

        /// <summary>
        /// Path to the client certificate (PFX) for production
        /// </summary>
        public string CertificatePath { get; set; } = string.Empty;

        /// <summary>
        /// Password for the PFX certificate
        /// </summary>
        public string CertificatePassword { get; set; } = string.Empty;
    }
}
