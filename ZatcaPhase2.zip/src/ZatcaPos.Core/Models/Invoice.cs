using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZatcaPos.Core.Models;

public class Invoice
{
    [Key]
    public int Id { get; set; }

    [Required, MaxLength(50)]
    public string InvoiceNumber { get; set; } = string.Empty;

    [Required]
    public DateTime InvoiceDate { get; set; }

    [Required, MaxLength(200)]
    public string SellerName { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string SellerTin { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string BuyerName { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string BuyerTin { get; set; } = string.Empty;

    public decimal TotalAmount { get; set; }
    public decimal VatAmount { get; set; }

    public bool IsSent { get; set; }
    public string? XmlData { get; set; }
    public string? SignedXml { get; set; } = string.Empty;
    public string? InvoiceHash { get; set; }
    public DateTime? SignedAt { get; set; } = DateTime.UtcNow;

    public string Uuid { get; set; } = Guid.NewGuid().ToString();
    public string? ClearanceStatus { get; set; }  = "Pending";
    public long Icv { get; set; }
    public string? PreviousInvoiceHash { get; set; }

    // Add this new property
    [NotMapped]
    public string? QrCodeBase64 { get; set; }

    public List<InvoiceLine> Lines { get; set; } = new();
}
