using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ZatcaPos.Core.Models
{
    public class InvoiceLine
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey(nameof(Invoice))]
        public int InvoiceId { get; set; } // FK to Invoice.Id

        public Invoice? Invoice { get; set; }

        [Required]
        public int LineNo { get; set; }

        [Required, MaxLength(200)]
        public string Description { get; set; } = string.Empty;

        [Range(0.01, double.MaxValue)]
        public decimal Quantity { get; set; } = 1m;

        [Range(0.00, double.MaxValue)]
        public decimal UnitPrice { get; set; } = 0m;

        [NotMapped]
        public decimal LineAmount => Quantity * UnitPrice;
    }
}
