using System;
using System.IO;
using System.Text;

namespace ZatcaPos.Core.Utils
{
    public static class TlvQrGenerator
    {
        public static string CreateTlvBase64(
            string sellerName,
            string sellerVat,
            decimal totalAmount,
            DateTime invoiceDateUtc,
            decimal vatAmount)
        {
            using var ms = new MemoryStream();

            WriteTlv(ms, 1, sellerName);
            WriteTlv(ms, 2, sellerVat);
            WriteTlv(ms, 3, invoiceDateUtc.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"));
            WriteTlv(ms, 4, totalAmount.ToString("0.00"));
            WriteTlv(ms, 5, vatAmount.ToString("0.00"));

            return Convert.ToBase64String(ms.ToArray());
        }

        private static void WriteTlv(Stream stream, byte tag, string value)
        {
            var valueBytes = Encoding.UTF8.GetBytes(value);

            stream.WriteByte(tag);
            stream.WriteByte((byte)valueBytes.Length);
            stream.Write(valueBytes, 0, valueBytes.Length);
        }
    }
}
