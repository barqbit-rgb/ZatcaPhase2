﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using QRCoder;

namespace ZatcaPos.Core.Utils
{
    public static class QrImageGenerator
    {
        // Input: TLV base64 string. Output: PNG bytes (raw image)
        public static byte[] CreateQrPngFromTlvBase64(string tlvBase64, int pixels = 250)
        {
            // ZATCA expects the QR content to be the TLV raw bytes, encoded in base64.
            // For the QR image we can encode the base64 string itself in the QR.
            using var qrGenerator = new QRCodeGenerator();
            using var qrData = qrGenerator.CreateQrCode(tlvBase64, QRCodeGenerator.ECCLevel.Q);
            using var qrCode = new PngByteQRCode(qrData);
            return qrCode.GetGraphic(pixels / 25); // scale factor
        }

        // If you prefer System.Drawing Bitmap:
        public static byte[] CreateQrPngFromText(string text, int pixels = 250)
        {
            using var qrGenerator = new QRCodeGenerator();
            using var qrData = qrGenerator.CreateQrCode(text, QRCodeGenerator.ECCLevel.Q);
            using var qrCode = new QRCode(qrData);
            using var bitmap = qrCode.GetGraphic(20);
            using var ms = new MemoryStream();
            bitmap.Save(ms, ImageFormat.Png);
            return ms.ToArray();
        }
    }
}
