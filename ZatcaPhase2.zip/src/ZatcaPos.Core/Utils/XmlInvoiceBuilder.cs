using System;
using System.Text;
using System.Xml;
using ZatcaPos.Core;
using ZatcaPos.Core.Models;

namespace ZatcaPos.Core.Utils
{
    public static class XmlInvoiceBuilder
    {
        public static string BuildInvoiceXml(Invoice invoice, string qrBase64)
        {
            var sb = new StringBuilder();
            var settings = new XmlWriterSettings { Indent = true, Encoding = Encoding.UTF8 };
            using var xw = XmlWriter.Create(sb, settings);

            // NOTE: Use the exact namespace and element names from ZATCA XSD for production.
            xw.WriteStartDocument();
            xw.WriteStartElement("Invoice"); // replace with official QName & namespace
            xw.WriteElementString("InvoiceNumber", invoice.InvoiceNumber);
            xw.WriteElementString("IssueDate", invoice.InvoiceDate.ToString("yyyy-MM-ddTHH:mm:ssK"));
            xw.WriteElementString("SellerName", invoice.SellerName);
            xw.WriteElementString("SellerTaxNo", invoice.SellerTin);
            if (!string.IsNullOrEmpty(invoice.BuyerName))
                xw.WriteElementString("BuyerName", invoice.BuyerName);
            if (!string.IsNullOrEmpty(invoice.BuyerTin))
                xw.WriteElementString("BuyerTaxNo", invoice.BuyerTin);

            xw.WriteStartElement("Lines");
            foreach (var ln in invoice.Lines)
            {
                xw.WriteStartElement("Line");
                xw.WriteElementString("LineNumber", ln.LineNo.ToString());
                xw.WriteElementString("Description", ln.Description);
                xw.WriteElementString("Quantity", ln.Quantity.ToString());
                xw.WriteElementString("UnitPrice", ln.UnitPrice.ToString("F2"));
                xw.WriteElementString("LineAmount", ln.LineAmount.ToString("F2"));
                xw.WriteEndElement();
            }
            xw.WriteEndElement(); // Lines

            xw.WriteElementString("TotalAmount", invoice.TotalAmount.ToString("F2"));
            xw.WriteElementString("TaxAmount", invoice.VatAmount.ToString("F2"));
            xw.WriteElementString("QRCode", qrBase64); // embed TLV base64

            xw.WriteEndElement(); // Invoice
            xw.WriteEndDocument();
            xw.Flush();
            return sb.ToString();
        }
    }
}
