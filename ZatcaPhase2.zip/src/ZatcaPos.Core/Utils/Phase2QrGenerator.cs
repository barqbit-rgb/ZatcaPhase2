﻿using System.Text;
using System.Security.Cryptography;
using ZatcaPos.Core.Models;

namespace ZatcaPos.Core.Utils;

public static class Phase2QrGenerator
{
    public static string Generate(Invoice invoice, string signedXml)
    {
        // Simulated cert data (replace with real in production)
        var publicKey = Convert.ToBase64String(Encoding.UTF8.GetBytes("PUBLIC_KEY"));
        var certSignature = Convert.ToBase64String(Encoding.UTF8.GetBytes("CERT_SIGNATURE"));
        var ecdsaSignature = Convert.ToBase64String(
            SHA256.HashData(Encoding.UTF8.GetBytes(signedXml))
        );

        var tlv = new List<byte>();

        WriteTlv(tlv, 1, invoice.SellerName);
        WriteTlv(tlv, 2, invoice.SellerTin);
        WriteTlv(tlv, 3, invoice.InvoiceDate.ToString("yyyy-MM-ddTHH:mm:ssZ"));
        WriteTlv(tlv, 4, invoice.TotalAmount.ToString("0.00"));
        WriteTlv(tlv, 5, invoice.VatAmount.ToString("0.00"));
        WriteTlv(tlv, 6, invoice.InvoiceHash);
        WriteTlv(tlv, 7, ecdsaSignature);
        WriteTlv(tlv, 8, publicKey);
        WriteTlv(tlv, 9, certSignature);

        return Convert.ToBase64String(tlv.ToArray());
    }

    private static void WriteTlv(List<byte> buffer, int tag, string value)
    {
        var valueBytes = Encoding.UTF8.GetBytes(value);
        buffer.Add((byte)tag);
        buffer.Add((byte)valueBytes.Length);
        buffer.AddRange(valueBytes);
    }
}
