﻿using System.IO;
using QRCoder;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Formats.Png;

namespace ZatcaPos.Core.Utils
{
    public static class QrPngGenerator
    {
        /// <summary>
        /// Generates a PNG QR code from a TLV Base64 string.
        /// </summary>
        /// <param name="tlvBase64">The TLV Base64 content for ZATCA Phase 2.</param>
        /// <param name="pixels">Width/height of the QR code in pixels (default 250).</param>
        /// <returns>Raw PNG bytes of the QR code.</returns>
        public static byte[] FromTlvBase64(string tlvBase64, int pixels = 250)
        {
            // 1. Generate QR code using QRCoder
            using var qrGenerator = new QRCodeGenerator();
            using var qrData = qrGenerator.CreateQrCode(tlvBase64, QRCodeGenerator.ECCLevel.Q);
            using var qrCode = new PngByteQRCode(qrData);

            // 2. Get raw PNG bytes
            var qrBytes = qrCode.GetGraphic(pixels / 25);

            // 3. Load PNG bytes into ImageSharp to ensure compatibility with PDF generators
            using var ms = new MemoryStream(qrBytes);
            using Image<Rgba32> image = Image.Load<Rgba32>(ms);

            using var outStream = new MemoryStream();
            image.Save(outStream, new PngEncoder());
            return outStream.ToArray();
        }
    }
}
