﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using ZatcaPos.Core.Models;

public static class PdfGenerator
{
    public static byte[] GenerateInvoicePdf(Invoice invoice, byte[] qrImageBytes)
    {
        return Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);
                page.DefaultTextStyle(x => x.FontSize(11));

                page.Content().Column(col =>
                {
                    col.Item().Text("Tax Invoice")
                        .FontSize(18)
                        .Bold();

                    col.Item().Text($"Invoice No: {invoice.InvoiceNumber}");
                    col.Item().Text($"Date: {invoice.InvoiceDate:yyyy-MM-dd HH:mm:ss}");

                    col.Item().PaddingVertical(10);

                    col.Item().Text($"Seller: {invoice.SellerName}");
                    col.Item().Text($"VAT No: {invoice.SellerTin}");

                    col.Item().PaddingVertical(10);

                    col.Item().Text($"Total: {invoice.TotalAmount:0.00}");
                    col.Item().Text($"VAT: {invoice.VatAmount:0.00}");

                    col.Item().PaddingTop(20);

                    // ✅ QR IMAGE — CORRECT
                    col.Item()
                        .AlignCenter()
                        .Width(140)
                        .Height(140)
                        .Image(qrImageBytes);
                });
            });
        }).GeneratePdf();
    }
}
