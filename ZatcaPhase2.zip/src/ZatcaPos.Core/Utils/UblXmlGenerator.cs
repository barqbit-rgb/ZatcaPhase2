﻿using System.Linq;
using System.Text;
using ZatcaPos.Core.Models;

namespace ZatcaPos.Core.Utils
{
    public static class UblXmlGenerator
    {
        public static string BuildInvoiceXml(Invoice invoice, string tlvBase64)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            sb.AppendLine("<Invoice xmlns=\"urn:oasis:names:specification:ubl:schema:xsd:Invoice-2\">");
            sb.AppendLine($"  <cbc:ID>{Escape(invoice.InvoiceNumber)}</cbc:ID>");
            sb.AppendLine($"  <cbc:IssueDate>{invoice.InvoiceDate:yyyy-MM-dd}</cbc:IssueDate>");

            sb.AppendLine("  <cac:AccountingSupplierParty>");
            sb.AppendLine($"    <cbc:CustomerAssignedAccountID>{Escape(invoice.SellerTin)}</cbc:CustomerAssignedAccountID>");
            sb.AppendLine($"    <cbc:PartyName>{Escape(invoice.SellerName)}</cbc:PartyName>");
            sb.AppendLine("  </cac:AccountingSupplierParty>");

            sb.AppendLine("  <cac:AccountingCustomerParty>");
            sb.AppendLine($"    <cbc:CustomerAssignedAccountID>{Escape(invoice.BuyerTin)}</cbc:CustomerAssignedAccountID>");
            sb.AppendLine($"    <cbc:PartyName>{Escape(invoice.BuyerName)}</cbc:PartyName>");
            sb.AppendLine("  </cac:AccountingCustomerParty>");

            int id = 1;
            foreach (var l in invoice.Lines)
            {
                sb.AppendLine("  <cac:InvoiceLine>");
                sb.AppendLine($"    <cbc:ID>{id}</cbc:ID>");
                sb.AppendLine($"    <cbc:InvoicedQuantity>{l.Quantity}</cbc:InvoicedQuantity>");
                sb.AppendLine($"    <cbc:LineExtensionAmount>{l.LineAmount:F2}</cbc:LineExtensionAmount>");
                sb.AppendLine($"    <cac:Item><cbc:Name>{Escape(l.Description)}</cbc:Name></cac:Item>");
                sb.AppendLine($"    <cac:Price><cbc:PriceAmount>{l.UnitPrice:F2}</cbc:PriceAmount></cac:Price>");
                sb.AppendLine("  </cac:InvoiceLine>");
                id++;
            }

            sb.AppendLine($"  <cbc:TaxTotal>{invoice.VatAmount:F2}</cbc:TaxTotal>");
            sb.AppendLine($"  <cbc:LegalMonetaryTotal>{invoice.TotalAmount:F2}</cbc:LegalMonetaryTotal>");

            // TLV (base64) included in an element (for preview). Real ZATCA expects TLV QR as separate requirement.
            sb.AppendLine($"  <cbc:UBLExtension><cbc:ExtensionContent><cbc:TLV>{tlvBase64}</cbc:TLV></cbc:ExtensionContent></cbc:UBLExtension>");

            sb.AppendLine("</Invoice>");
            return sb.ToString();
        }

        private static string Escape(string s) => System.Security.SecurityElement.Escape(s ?? string.Empty);
    }
}
