﻿namespace ZatcaPos.Core.Services
{
    public class ZatcaAuthStub
    {
        // In dev, just returns a fake token string
        public static string GetFakeToken()
        {
            return "FAKE-JWT-TOKEN-FOR-DEV";
        }
    }
}