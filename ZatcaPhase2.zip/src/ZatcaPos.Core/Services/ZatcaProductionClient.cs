﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ZatcaPos.Core.Services
{
    public class ZatcaProductionClient : IZatcaClient
    {
        private readonly HttpClient _http;

        public ZatcaProductionClient(HttpClient http)
        {
            _http = http;
        }

        // New method required by IZatcaClient
        public void SetAuthToken(string token)
        {
            _http.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);
        }

        public async Task<ZatcaResponse> SendInvoiceAsync(string xml, bool isClearance)
        {
            if (_http.BaseAddress == null)
                throw new HttpRequestException("HttpClient BaseAddress is not configured.");

            var content = new StringContent(xml, Encoding.UTF8, "application/xml");

            // Unified API v2 endpoint
            var path = "api/Invoice/Submit";
            path += isClearance ? "?type=clearance" : "?type=reporting";

            var response = await _http.PostAsync(path, content);
            var raw = await response.Content.ReadAsStringAsync();

            return new ZatcaResponse
            {
                StatusCode = (int)response.StatusCode,
                RawResponse = raw
            };
        }
    }
}