﻿using System.Threading.Tasks;

namespace ZatcaPos.Core.Services
{
    public class MockZatcaClient : IZatcaClient
    {
        // New method required by IZatcaClient
        public void SetAuthToken(string token)
        {
            // In mock mode, you don’t need to do anything
            // but you must implement the method to satisfy the interface
        }

        public Task<ZatcaResponse> SendInvoiceAsync(string xml, bool isClearance)
        {
            return Task.FromResult(new ZatcaResponse
            {
                StatusCode = 200,
                RawResponse = "MOCK SUCCESS"
            });
        }
    }
}