using System.Threading.Tasks;

namespace ZatcaPos.Core.Services
{
    public interface IZatcaClient
    {
        /// <summary>
        /// Sets the JWT Bearer token for authenticated requests.
        /// </summary>
        /// <param name="token">JWT token obtained from Partner Login</param>
        void SetAuthToken(string token);

        /// <summary>
        /// Sends a signed invoice XML to ZATCA Unified API v2.
        /// </summary>
        /// <param name="xml">Signed XML invoice</param>
        /// <param name="isClearance">True for clearance, false for reporting</param>
        /// <returns>Status code and raw response JSON</returns>
        Task<ZatcaResponse> SendInvoiceAsync(string xml, bool isClearance);
    }

    public class ZatcaResponse
    {
        /// <summary>
        /// HTTP status code returned by ZATCA.
        /// </summary>
        public int StatusCode { get; set; }

        /// <summary>
        /// Raw JSON response body from ZATCA.
        /// </summary>
        public string RawResponse { get; set; } = string.Empty;
    }
}