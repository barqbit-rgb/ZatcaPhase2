﻿using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Xml;

public static class XadesSigner
{
    public static string SignInvoice(
        string xml,
        string certPath,
        string certPassword)
    {
        var xmlDoc = new XmlDocument
        {
            PreserveWhitespace = true
        };
        xmlDoc.LoadXml(xml);

        var cert = new X509Certificate2(
            certPath,
            certPassword,
            X509KeyStorageFlags.MachineKeySet);

        var signedXml = new SignedXml(xmlDoc)
        {
            SigningKey = cert.GetRSAPrivateKey()
        };

        var reference = new Reference
        {
            Uri = ""
        };
        reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
        reference.AddTransform(new XmlDsigC14NTransform());

        signedXml.AddReference(reference);

        signedXml.KeyInfo = new KeyInfo();
        signedXml.KeyInfo.AddClause(
            new KeyInfoX509Data(cert));

        signedXml.ComputeSignature();

        var signature = signedXml.GetXml();
        xmlDoc.DocumentElement!.AppendChild(
            xmlDoc.ImportNode(signature, true));

        return xmlDoc.OuterXml;
    }
}
