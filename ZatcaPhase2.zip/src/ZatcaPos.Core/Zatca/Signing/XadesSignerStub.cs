﻿using System;

namespace ZatcaPos.Core.Zatca.Signing
{
    public class XadesSignerStub : IXadesSigner
    {
        public string SignInvoiceXml(string unsignedXml)
        {
            if (string.IsNullOrWhiteSpace(unsignedXml))
                throw new ArgumentException("Invoice XML cannot be empty");

            // Placeholder signature node
            var signatureBlock =
@"
<!-- XAdES Signature Placeholder -->
<ds:Signature xmlns:ds=""http://www.w3.org/2000/09/xmldsig#"">
    <ds:SignedInfo>
        <ds:SignatureMethod Algorithm=""http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"" />
    </ds:SignedInfo>
    <ds:SignatureValue>PLACEHOLDER_SIGNATURE</ds:SignatureValue>
</ds:Signature>
";

            // Append signature before closing root element
            var insertIndex = unsignedXml.LastIndexOf("</");
            if (insertIndex <= 0)
                throw new InvalidOperationException("Invalid XML structure");

            return unsignedXml.Insert(insertIndex, signatureBlock);
        }
    }
}
