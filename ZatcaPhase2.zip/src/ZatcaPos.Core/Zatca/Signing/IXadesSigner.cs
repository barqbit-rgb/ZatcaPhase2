﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZatcaPos.Core.Zatca.Signing
{
    public interface IXadesSigner
    {
        string SignInvoiceXml(string unsignedXml);
    }
}

