﻿using System;
using ZatcaPos.Core.Models;
using ZatcaPos.Core.Utils;
using ZatcaPos.Core.Zatca.Signing;

namespace ZatcaPos.Core.Zatca
{
    public class ZatcaPipelineResult
    {
        public string InvoiceXml { get; set; } = string.Empty;
        public string InvoiceHash { get; set; } = string.Empty;
        public string QrCodeBase64 { get; set; } = string.Empty;
    }

    public static class ZatcaPipeline
    {
        // Use stub signer for testing. Replace with real IXadesSigner for production.
        private static readonly IXadesSigner _signer = new XadesSignerStub();

        /// <summary>
        /// Processes an invoice:
        /// - Generates XML
        /// - Signs XML
        /// - Computes hash
        /// - Generates TLV QR code
        /// </summary>
        public static ZatcaPipelineResult ProcessInvoice(Invoice invoice)
        {
            if (invoice == null)
                throw new ArgumentNullException(nameof(invoice));

            // Generate unsigned XML (updated signature to include QR base64)
            string unsignedXml = XmlInvoiceBuilder.BuildInvoiceXml(invoice, ""); // pass empty string, QR will be set after

            // Sign the XML using XAdES signer
            string signedXml = _signer.SignInvoiceXml(unsignedXml);

            // Generate base64 hash of signed XML
            string invoiceHash = ZatcaHashGenerator.GenerateHashBase64(signedXml);

            // Generate TLV QR code for invoice
            string qrBase64 = TlvQrGenerator.CreateTlvBase64(
                invoice.SellerName,
                invoice.SellerTin,
                invoice.TotalAmount,
                invoice.InvoiceDate,
                invoice.VatAmount
            );

            // Set values on invoice object
            invoice.QrCodeBase64 = qrBase64;
            invoice.InvoiceHash = invoiceHash;

            return new ZatcaPipelineResult
            {
                InvoiceXml = signedXml,
                InvoiceHash = invoiceHash,
                QrCodeBase64 = qrBase64
            };
        }
    }
}
