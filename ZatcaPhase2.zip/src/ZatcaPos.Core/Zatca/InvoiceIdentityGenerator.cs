﻿using System.Security.Cryptography;

public static class InvoiceIdentityGenerator
{
    public static string GenerateUuid()
        => Guid.NewGuid().ToString();

    public static long NextIcv(long lastIcv)
        => lastIcv + 1;

    public static string InitialPih()
        => Convert.ToBase64String(
            SHA256.HashData(Array.Empty<byte>())
        );
}
