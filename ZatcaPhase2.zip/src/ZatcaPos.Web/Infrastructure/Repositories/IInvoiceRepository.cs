﻿using ZatcaPos.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ZatcaPos.Web.Infrastructure.Repositories
{
    public interface IInvoiceRepository
    {
        Task AddInvoiceAsync(Invoice invoice);
        Task<Invoice?> GetInvoiceAsync(string invoiceNumber);
        Task<List<Invoice>> GetAllInvoicesAsync();
    }
}
