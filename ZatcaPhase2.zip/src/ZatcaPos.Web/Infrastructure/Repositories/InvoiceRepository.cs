﻿using Microsoft.EntityFrameworkCore;
using ZatcaPos.Core.Models;
using ZatcaPos.Web.Infrastructure.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ZatcaPos.Web.Infrastructure.Repositories
{
    public class InvoiceRepository : IInvoiceRepository
    {
        private readonly ApplicationDbContext _db;

        public InvoiceRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task AddInvoiceAsync(Invoice invoice)
        {
            await _db.Invoices.AddAsync(invoice);
            await _db.SaveChangesAsync();
        }

        public async Task<Invoice?> GetInvoiceAsync(string invoiceNumber)
        {
            return await _db.Invoices
                .Include(i => i.Lines)
                .FirstOrDefaultAsync(i => i.InvoiceNumber == invoiceNumber);
        }

        public async Task<List<Invoice>> GetAllInvoicesAsync()
        {
            return await _db.Invoices
                .Include(i => i.Lines)
                .OrderByDescending(i => i.InvoiceDate)
                .ToListAsync();
        }
    }
}
