﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using QuestPDF.Infrastructure;
using ZatcaPos.Core.Configuration;
using ZatcaPos.Core.Services;
using ZatcaPos.Web.Infrastructure.Data;
using ZatcaPos.Web.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// ✅ QuestPDF license
QuestPDF.Settings.License = LicenseType.Community;

// Razor Pages + Blazor
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

// EF Core DbContext
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Repositories
builder.Services.AddScoped<IInvoiceRepository, InvoiceRepository>();

// Bind ZATCA options
builder.Services.Configure<ZatcaOptions>(builder.Configuration.GetSection("Zatca"));

// Named HttpClient for ZATCA Unified API v2
builder.Services.AddHttpClient("Zatca", (sp, client) =>
{
    var options = sp.GetRequiredService<IOptions<ZatcaOptions>>().Value;

    if (string.IsNullOrWhiteSpace(options.BaseUrl))
        throw new InvalidOperationException("ZATCA BaseUrl must be configured.");

    client.BaseAddress = new Uri(options.BaseUrl);

    // Accept JSON responses
    client.DefaultRequestHeaders.Add("Accept", "application/json");

    // If you already have a dev token, set it here
    if (!string.IsNullOrWhiteSpace(options.ApiKey))
    {
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {options.ApiKey}");
    }
});

// Register ZATCA client (same for sandbox & production)
builder.Services.AddScoped<IZatcaClient>(sp =>
{
    var httpClientFactory = sp.GetRequiredService<IHttpClientFactory>();
    var httpClient = httpClientFactory.CreateClient("Zatca");
    return new ZatcaClient(httpClient);
});

var app = builder.Build();

// Middleware
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();