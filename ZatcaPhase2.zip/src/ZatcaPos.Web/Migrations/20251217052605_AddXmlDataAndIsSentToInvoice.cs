﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZatcaPos.Web.Migrations
{
    /// <inheritdoc />
    public partial class AddXmlDataAndIsSentToInvoice : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ClearanceStatus",
                table: "Invoices",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<long>(
                name: "Icv",
                table: "Invoices",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<string>(
                name: "InvoiceHash",
                table: "Invoices",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PreviousInvoiceHash",
                table: "Invoices",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "SignedAt",
                table: "Invoices",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "Uuid",
                table: "Invoices",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ClearanceStatus",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "Icv",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "InvoiceHash",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "PreviousInvoiceHash",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "SignedAt",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "Uuid",
                table: "Invoices");
        }
    }
}
