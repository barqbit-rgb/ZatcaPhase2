﻿namespace ZatcaPos.Infrastructure;

public class Class1
{

}
