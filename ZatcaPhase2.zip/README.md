# ZatcaPos - Blazor Server (Demo scaffold)

This repository is a minimal Blazor Server scaffold implementing a baseline for ZATCA Phase-2 (simulation) e-invoicing integration.

IMPORTANT:
- This is a demo scaffold. You must replace placeholders (TIN, EGS Unit ID, endpoints) and implement full XSD compliance, WS-Security headers, and PDF/A-3 generation as required by ZATCA.
- Do NOT commit private keys. Use a secure key vault for production.

How to run:
1. Open the solution `ZatcaPos.sln` with Visual Studio 2022 (ensure .NET 8 SDK is installed).
2. Set `ZatcaPos.Web` as startup project and run.
3. Go to `/create-invoice` to generate and send a sample invoice to the simulated client (the client currently uses placeholder endpoints and simulated responses).

Files to review and update:
- `src/ZatcaPos.Web/appsettings.json`
- `src/ZatcaPos.Core/Utils/TlvQrGenerator.cs` (confirm TLV tags and order against ZATCA PDF)
- `src/ZatcaPos.Core/Utils/XmlInvoiceBuilder.cs` (replace XML element names/namespaces with official XSD)
- `src/ZatcaPos.Core/Services/ZatcaClient.cs` (implement real onboarding and invoice sending using official Developer Portal API paths)

References:
- ZATCA Developer Portal & Technical Guideline (use official PDFs from ZATCA / FATOORA).
